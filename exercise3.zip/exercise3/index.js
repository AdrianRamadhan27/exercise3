var express     = require('express');
var app         = express();
var logger      = require('morgan');

var expressku   = require('./routes/expressku');
 

var conn        = require('express-myconnection');
var mysql       = require('mysql');

app.set('port', process.env.port || 3000);
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use('/public', express.static(__dirname + '/public'));
// app.use('/public', express.static(path.join(__dirname, 'public')));


app.use(
    conn(mysql, {
        host: "localhost",
        user: "root",
        password: "",
        port: 3306,
        database: "exercise_3_node"
    }, 'single')
);


app.get('/', function (req, res) {
    res.send('Server is running on port ' + app.get('port'));
    // res.send('Server-nya running bosquh..!');
});

app.get('/express', expressku.home);
app.get('/express/products', expressku.products);
app.get('/express/products_detail/:id_product', expressku.products_detail);



app.listen(app.get('port'), function () {
    console.log('Server is running on port ' + app.get('port'));
});